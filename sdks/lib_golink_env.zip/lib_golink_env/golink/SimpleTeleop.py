import goLinkManager as glm
import time
import keyboard
import threading
from queue import *

if __name__ == "__main__":
    POWER_DIST = 2
    MOTOR_DRIVER_LEFT = 4
    MOTOR_DRIVER_RIGHT = 5
    SPEED  = 25 # %
    NONSPEED = 5
    DELAY = 0.001
    systemNodeIds = [POWER_DIST, MOTOR_DRIVER_LEFT, MOTOR_DRIVER_RIGHT]
    man = glm.GoLinkManager(systemNodeIds)
    man.startNodes()
    global lSpeed
    lSpeed = Queue()
    lSpeed.put(0)
    global rSpeed
    rSpeed = Queue()
    rSpeed.put(0)
    
	
    def t_updateMotor(index):
        
        while(True):           
   
             if(index == MOTOR_DRIVER_LEFT):
                 m = "L: "
                 if(not lSpeed.empty()):
                     speed = lSpeed.get()

             elif(index == MOTOR_DRIVER_RIGHT):
                 m = "R: "
                 if(not rSpeed.empty()):
                     speed = rSpeed.get()
             
             print("t: " + str(speed))
             if man.isNewData(index):
                print(m + str(man.getData(index)))
                man.setData(index, {'spr' : int(speed)})
            
             time.sleep(0.05)

    leftMotor = threading.Thread(target=t_updateMotor, args = (MOTOR_DRIVER_LEFT, ))
    rightMotor = threading.Thread(target=t_updateMotor, args = (MOTOR_DRIVER_RIGHT,))
    leftMotor.start()
    rightMotor.start()

    while True:
       key = input("Key (wasd): ")
       if(key == 'w'):
           print("W")
           lS = SPEED
           rS = SPEED

       elif(key == 's'):
           print("S")
           lS = 0
           rS = 0

       elif(key == 'd'):
           print("D")
           lS = NONSPEED
           rS = SPEED

       elif(key == 'a'):
           print("A")
           lS = SPEED
           rS = NONSPEED
            
       print("MT: " + str(lS) + " - " + str(rS))
       lSpeed.put(lS)
       rSpeed.put(rS)
       time.sleep(0.05)
            

        

