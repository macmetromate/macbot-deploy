import goLinkManager as glm
import time

if __name__ == "__main__":
    POWER_DIST = 2
    MOTOR_DRIVER_LEFT = 4
    MOTOR_DRIVER_RIGHT = 5
    
    systemNodeIds = [POWER_DIST, MOTOR_DRIVER_LEFT, MOTOR_DRIVER_RIGHT]
    man = glm.GoLinkManager(systemNodeIds)
    man.startNodes()

    motorChoice = input("Which motor would you like to control? (left/right): ")
    canIndex = None
    if (motorChoice == "left" or motorChoice == "LEFT" or motorChoice == "l" or motorChoice == "L"):
        canIndex = MOTOR_DRIVER_LEFT
    elif (motorChoice == "right" or motorChoice == "RIGHT" or motorChoice == "r" or motorChoice == "R"):
        canIndex = MOTOR_DRIVER_RIGHT
    
    motorSpeed = input("Speed? (%): ")

    while 1:
        
        if man.isNewData(canIndex):
            print(man.getData(canIndex))
            man.setData(canIndex, {'spr' : int(motorSpeed)})
            
        time.sleep(0.05)

