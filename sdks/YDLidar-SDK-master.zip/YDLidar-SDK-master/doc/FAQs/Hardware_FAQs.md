# Hardware FAQs

---
### Which types of YD LiDAR are supported by YDLIDAR-SDK?
please visit [this](https://github.com/YDLIDAR/YDLidar-SDK/blob/master/doc/Dataset.md) page.

---
**More Hardware FAQs to follow.**
